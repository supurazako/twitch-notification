function sendNotifications(twitchUsername, currentTitle) {
    sendDiscordNotification(twitchUsername, currentTitle);
    postTweet(twitchUsername, currentTitle);
    sendEmail(twitchUsername, currentTitle);
}


async function sendDiscordNotification(twitchUsername, currentTitle) {
    const https = require('https');
    
    // Discord Webhook URL
    const webhookUrl = 'https://discord.com/api/webhooks/1090999980690509827/z-GwEJRAt0cPkTKLXM37WFJFN85az6FLxrlZTdEHUY3KbLAQi4NvaD9s3jMIVyOyxIZw';
  
    // 送信するメッセージ
    const message = {
        content: `<@&1090963184271237251> ${twitchUsername}が「${currentTitle}」にタイトルを変更しました！\nhttps://twitch.tv/${twitchUsername}`
    }
  
    // WebhookにPOSTリクエストを送信
    const options = {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
    };
  
    const req = https.request(webhookUrl, options, (res) => {
        console.log(`statusCode: ${res.statusCode}`);
  
        res.on('data', (d) => {
        process.stdout.write(d);
        });
    });
  
    req.on('error', (error) => {
        console.error(error);
    });
  
    req.write(JSON.stringify(message));
    req.end();
}


function postTweet(twitchUsername, currentTitle) {
    const Twitter = require('twitter')
    const client = new Twitter({
        consumer_key: process.env.CONSUMER_KEY,
        consumer_secret: process.env.CONSUMER_SECRET,
        access_token_key: process.env.ACCESS_TOKEN_KEY,
        access_token_secret: process.env.ACCESS_TOKEN_SECRET
    });

    const tweetContent = `${twitchUsername}さんがタイトルを「${currentTitle}」に変更しました！`;
    client.post('statuses/update', {status: tweetContent}, function(error, tweet, response) {
        if (error) {
            console.log(error);
        } else {
            console.log(tweet);
        }   
    });
}

const nodemailer = require('nodemailer');
const getAddresses = require('./emails');

const senderMailAddress = process.env.SENDER_MAIL_ADDRESS;
const senderMailPass = process.env.SENDER_MAIL_PASS;
const unsubscribeMailUrl = process.env.UNSUBSCRIBE_MAIL_URL;

async function sendEmail(twitchUsername, currentTitle) {
    // トランスポーターを作成
    const transporter = nodemailer.createTransport({
        // 使用するメールサービス
        service: 'Gmail',
        auth: {
            uesr: senderMailAddress, // 送信元メールアドレス
            pass: senderMailPass, // 送信元メールのパスワード
        },
    });
    // 送信先のアドレスを取得
    const recipientMail = getAddresses();

    // メールのオプションを設定
    const mailOptions = {
        from: senderMailAddress, // 送信元のメールアドレス
        to: recipientMail, // 送信先、受信者のメールアドレス
        subject: `${twitchUsername}さんがタイトルを変更しました！`,
        html: `<p>${twitchUsername}さんが「<a href="https://twitch.tv/${twitchUsername}>${currentTitle}</a>」に変更しました！</p>
        <br>
        <p>メール配信停止は<a href="${unsubscribeMailUrl}">こちら</a></p>`,
    };

    // メールを送信
    try {
        const info = await transporter.sendMail(mailOptions);
        console.log('メールが送信されました:', info.messageId);
    } catch (error) {
            console.error('メールの送信中にエラーが発生しました', error);
    }
}

module.exports = {
    sendNotifications
}