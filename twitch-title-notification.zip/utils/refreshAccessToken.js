const fetch = require('node-fetch')

const refreshAccessToken = async (twitchClientId, twitchClientSecret, twitchAccessToken, refreshToken, refreshInterval) => {
    const refreshTokenUrl = `https://id.twitch.tv/oauth2/token?grant_type=refresh_token&refresh_token=${refreshToken}&client_id=${twitchClientId}&client_secret=${twitchClientSecret}`;
    const response = await fetch(refreshTokenUrl, { method: 'POST' });
    const data = await response.json();
    twitchAccessToken = data.access_token;
    console.log(`Access token refreshed: ${twitchAccessToken}`);
};


module.exports = {
    refreshAccessToken
}