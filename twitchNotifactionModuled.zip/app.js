const twitchClientId = process.env.TWITCH_CLIENT_ID;
const twitchUsername = 'oniyadayo';
let twitchAccessToken = process.env.TWITCH_ACCESS_TOKEN;
const refreshToken = process.env.REFRESH_TOKEN;
const twitchClientSecret = process.env.TWITCH_CLIENT_SECRET;


const refreshAccessToken = require('./utils/refreshAccessToken');
// twitchのアクセストークンをリフッレシュ
setInterval(() => {
    refreshAccessToken(twitchClientId, twitchClientSecret, twitchAccessToken, refreshToken);
}, 1000 * 60 * 30);


// setInterval(refreshAccessToken(twitchClientId, twitchClientSecret, twitchAccessToken, refreshToken), 1000 * 60 * 30);
// 上の場合だとエラーになる

// 配信情報を確認
const checkTitleChange = require('./utils/streamInfo');
const sendNotifications = require('./utils/notifications');

console.log('checkTitleChange:', checkTitleChange);

async function notificationInterval() {
    try {
        // 戻り値を取得
        console.log('戻り値を取得する');
        const { isTitleChanged, currentTitle } = await checkTitleChange(twitchUsername, twitchAccessToken, twitchClientId);
        if (isTitleChanged == true) {
            try {
                // 通知を送る
                sendNotifications(twitchUsername, currentTitle);
            } catch (error) {
                console.error('An error occurred while sending notifications:', error);
            }
        }   
    } catch (error) {
        console.error('An error occurred:', error);
    }
}

setInterval(notificationInterval, 1000 * 15);