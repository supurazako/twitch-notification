const { GoogleSpreadsheet } = require('google-spreadsheet');
const spreadsheetId = process.env.SPREADSHEET_ID;
const spreadsheetName = process.env.SPREADSHEET_NAME;
const serviceAccountMail = process.env.SERVICE_ACCOUNT_MAIL;
const serviceAccountPrivateKey = process.env.SERVICE_ACCOUNT_PRIVATE_KEY;

const range = 'B2:B'; // B列の二行目から最終行までの範囲

// スプレッドシートのデータ取得
async function getAddresses() {
  try {
    const doc = new GoogleSpreadsheet(spreadsheetId);
    await doc.useServiceAccountAuth({
      client_email: serviceAccountMail,
      private_key: serviceAccountPrivateKey,
    });

    await doc.loadInfo(); // スプレッドシートの情報を読み込む
    const sheet = doc.sheetsByName[spreadsheetName]; // インデックスに基づいてシートを選択（0は最初のシートを意味します）
    const addresses = await sheet.getRange(range).getValues();
    return addresses;

  } catch (err) {
    console.error('addressesの取得に失敗しました:', err);
  }
}

module.exports = {
  getAddresses
}
