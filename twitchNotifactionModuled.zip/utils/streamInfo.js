const fetch = require('node-fetch');


async function getBroadcasterId(twitchUsername, twitchAccessToken, twitchClientId) {
    const url = `https://api.twitch.tv/helix/users?login=${twitchUsername}`;
    console.log(`access token: ${twitchAccessToken}`);
    const response = await fetch(url, {
        headers: {
            'Client-ID': twitchClientId,
            'Authorization': `Bearer ${twitchAccessToken}`
        }
    });
    const json = await response.json();
    return json.data[0].id;
}


async function getStreamTitle(twitchUsername, twitchAccessToken, twitchClientId) {
    const twitchUserId = getBroadcasterId(twitchUsername, twitchAccessToken, twitchClientId);
    const url = `https://api.twitch.tv/helix/channels?broadcaster_id=${twitchUserId}`;
  
    return fetch(url, {
        headers: {
            'Client-ID': twitchClientId,
            'Authorization': `Bearer ${twitchAccessToken}`,
        },
    })
        .then(response => {
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        return response.json();
    })
        .then(data => {
        if (data.data.length === 0) {
            throw new Error('Channel not found');
        }
        const streamTitle = data.data[0].title;
        return streamTitle;
    })
      .catch(error => console.error(error));
}


let previousTitle = 'none';
let currentTitle = 'none';
let isInited = false;
let isTitleChanged;

async function checkTitleChange(twitchUsername, twitchAccessToken, twitchClientId) {
    try {
        let streamTitle = await getStreamTitle(twitchUsername, twitchAccessToken, twitchClientId);
        if (streamTitle.length > 0) {
            currentTitle = streamTitle;
            if (currentTitle !== previousTitle) {
                //if inited, send notifaction
                if (isInited == true) {
                    previousTitle = currentTitle;
                    isTitleChanged = true;
                    console.log(`changed to ${currentTitle}`);
                    return {isTitleChanged, currentTitle};
                } else {
                    isInited = true;
                    isTitleChanged = false;
                    console.log('Initialization is complete.')
                    return {isTitleChanged, currentTitle};
                }
            }
            else {
                isTitleChanged = false;
                console.log(`nochange, current title: ${currentTitle}`);
                return {isTitleChanged, currentTitle};
            }
        }
        else {
            isTitleChanged = false;
            console.log(`no change, current title: ${currentTitle}`);
            return {isTitleChanged, currentTitle};
        }
    } catch (error) {
        console.error(error);
    }
}


module.exports = {
    checkTitleChange
};